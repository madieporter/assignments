const express = require("express");
const app = express();
require ("dotenv").config();
const expressJwt = require("express-jwt");
const morgan = require("morgan");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const PORT = process.env.PORT || 1234;


app.use(morgan("dev"));
app.use(bodyParser.json());

//next three app.use is to have our app use the auth routes -- sending the token to the client
//restricting certain routes from being reached unless there is a legit token included in the request,
//so that only someone who is logged in can access them. 
app.use("/auth", require("./routes/authRouter"));
//apply express-jwt middleware on anything using the route /api
//this part is making it so we are not restricting the authentication routes, to the login is still accessible
//make the app use express-jwt authentication middleware on anything starting with "/api"
//express-jwt will verify the token for us, and then set the decoded user object
app.use("/api", expressJwt({secret: process.env.SECRET}));

// ties the user object to req.user in our server 
// adding `/api` before /<link> so it must go through the express-jwt middleware before accessing any todos, so we can reference 
// the currently logged-in user 
app.use("/api/todo", require("./routes/todoRouter"));


//connect to db
mongoose.set('useCreateIndex', true);
mongoose.connect("mongodb://localhost:27017/todo-auth-example",
    { useNewUrlParser: true },
    (err) => {
        if (err) throw err;
        console.log("Connected to the database");
    }
);

//This is a global error handler, it will process all errors in our server that are passed through next()
app.use((err, req, res, next) => {
    console.log(err);
    if (err.name === "UnauthorizedError"){
        //express-jwt gives the 401 status to the err object for us
        res.status(err.status)
    } 
    return res.send ({
        message: err.message
    })
})

app.use((err, req, res, next) => {
    console.log(err);
    return res.send({ message: err.message });
});

app.listen(PORT, () => {
    console.log(`[+] Starting server on port ${PORT}`);
});
